export class Register{
constructor(
public userName ='',
public password ='',
public email ='',
)
{}


}
    
