export class User{
constructor(
public userName ='',
public password ='',
public email ='',
)
{}


}
    
